/**
 * StarTechSteel – รับคำขอลูกค้าจากแอปคำนวณโครงหลังคา
 * วางโค้ดนี้ใน Google Apps Script ที่ผูกกับ Google Sheet (ส่วนขยาย > Apps Script)
 * แล้ว Deploy เป็น Web app (Execute as: Me, Who has access: Anyone)
 * นำ URL ที่ได้ไปใส่ใน CONTACT.endpoint ของไฟล์ HTML
 */

// ===== ตั้งค่า =====
const SHEET_NAME = 'คำขอลูกค้า';

// อีเมลรับแจ้งเตือนของแต่ละสาขา (เว้นว่าง = ไม่ส่งอีเมล)
const BRANCH_EMAIL = {
  faorai:      'startechfaorai@gmail.com',             // สาขาเฝ้าไร่
  chuenchom:   'startechchuenchom@gmail.com',          // สาขาชื่นชม
  kalasin:     'startechkalasin@gmail.com',            // สาขากาฬสินธุ์
  surin:       'Sales@startechsteelgroup.com',         // สำนักงานใหญ่ สุรินทร์
  khukhan:     'wiwat.k@startechsteelgroup.com',       // สาขาขุขันธ์
  prathai:     'prathai@startechsteelgroup.com',       // สาขาประทาย
  rayong:      'sikan.w@startechsteelgroup.com',       // สาขาระยอง
  prachinburi: 'witaya.m@startechsteelgroup.com',      // สาขาปราจีนบุรี
  wangnamyen:  'wanchalerm.k@startechsteelgroup.com',  // สาขาวังน้ำเย็น
  saraburi:    'saraburi@startechsteelgroup.com',      // สาขาสระบุรี
  central:     'sttm.energy@gmail.com',                // ส่วนกลาง
};
const CC_CENTRAL = true; // ส่งสำเนาทุกรายการให้ส่วนกลางด้วย
// ผู้รับสำเนาทุกรายการเพิ่มเติม
const CC_ALWAYS = [
  'kittimatsrisamer@gmail.com', // คุณหมิว
  'patty_treesak@hotmail.com',  // คุณแพท
  'o_siripong@hotmail.com',     // คุณโอ
];

// (ไม่บังคับ) แจ้งเข้า LINE กลุ่มผ่าน LINE Official Account (Messaging API)
// ใส่ Channel access token และ groupId/userId ปลายทางของแต่ละสาขา
const LINE_TOKEN = '';
const LINE_TO = {}; // เช่น { faorai: 'Cxxxx', central: 'Cyyyy' }
// ===================

function doPost(e) {
  try {
    const d = JSON.parse(e.postData.contents);
    if (!d.customer || !d.customer.name || !/^0\d{8,9}$/.test(String(d.customer.phone || ''))) {
      return json_({ ok: false, error: 'invalid' });
    }
    const rid = d.routeTo && d.routeTo.id;
    const branchId = (rid && rid !== 'central' && BRANCH_EMAIL.hasOwnProperty(rid)) ? rid : 'central';

    // 1) บันทึกลง Google Sheet
    const ss = SpreadsheetApp.getActiveSpreadsheet();
    const sh = ss.getSheetByName(SHEET_NAME) || ss.insertSheet(SHEET_NAME);
    if (sh.getLastRow() === 0) {
      sh.appendRow(['เวลา', 'เลขอ้างอิง', 'ประเภท', 'ส่งถึง', 'ระยะ (กม.)', 'ชื่อ', 'โทร', 'LINE',
        'จังหวัด', 'อำเภอ', 'ตำบล', 'ที่อยู่', 'แผนที่', 'หมายเหตุ', 'ทรงหลังคา', 'ขนาด (ก×ย×ส)',
        'ราคาขายวัสดุโครง', 'ข้อความเต็ม', 'สถานะ']);
      sh.setFrozenRows(1);
    }
    const L = d.location || {}, J = d.job || {}, C = d.customer;
    sh.appendRow([
      new Date(), d.id, d.wantLabel, d.routeTo.name, d.routeTo.distanceKm, C.name, "'" + C.phone, C.line || '',
      L.province, L.district, L.tambon || '', L.address || '',
      L.lat ? 'https://maps.google.com/?q=' + L.lat + ',' + L.lon : '',
      C.note || '', J.roof || '', J.width ? J.width + '×' + J.length + '×' + J.height : '',
      J.sellTotal || '', d.message || '', 'รอติดต่อ'
    ]);

    // 2) อีเมลแจ้งสาขา
    const to = BRANCH_EMAIL[branchId];
    const ccList = (CC_CENTRAL && branchId !== 'central' ? [BRANCH_EMAIL.central] : []).concat(CC_ALWAYS).filter(x => x && x !== to);
    const cc = ccList.join(',');
    const subject = '[' + d.wantLabel + '] ' + C.name + ' ' + C.phone + ' → ' + d.routeTo.name + ' (' + d.id + ')';
    if (to || cc) {
      MailApp.sendEmail({ to: to || cc, cc: to ? cc : '', subject: subject, body: d.message || subject });
    }

    // 3) แจ้ง LINE (ถ้าตั้งค่าไว้)
    const lineTo = LINE_TO[branchId];
    if (LINE_TOKEN && lineTo) {
      UrlFetchApp.fetch('https://api.line.me/v2/bot/message/push', {
        method: 'post', contentType: 'application/json',
        headers: { Authorization: 'Bearer ' + LINE_TOKEN },
        payload: JSON.stringify({ to: lineTo, messages: [{ type: 'text', text: (d.message || subject).slice(0, 4900) }] }),
        muteHttpExceptions: true,
      });
    }
    return json_({ ok: true, id: d.id });
  } catch (err) {
    return json_({ ok: false, error: String(err) });
  }
}

function json_(o) {
  return ContentService.createTextOutput(JSON.stringify(o)).setMimeType(ContentService.MimeType.JSON);
}
