/**
 * StarTechSteel – รับคำขอลูกค้าจากแอปคำนวณโครงหลังคา  (v2 · 23 พ.ย. 2569)
 * วางโค้ดนี้ใน Google Apps Script ที่ผูกกับ Google Sheet (ส่วนขยาย > Apps Script)
 * แล้ว Deploy เป็น Web app (Execute as: Me, Who has access: Anyone)
 * นำ URL ที่ได้ไปใส่ใน CONTACT.endpoint ของไฟล์ HTML
 *
 * ทุกคำขอ: 1) บันทึก Google Sheet  2) อีเมลสาขา + สำเนา  3) ส่งต่อเข้า Airtable + LINE (Worker เดิม)
 * ขั้นที่ 2 และ 3 แยกกัน ถ้าอันใดพลาด อีกอันยังทำงาน และบันทึกผลไว้ในคอลัมน์ "ผลการส่ง"
 *
 * เปลี่ยนจาก v1: ส่งต่อเข้า Worker · กันสูตรแปลกปลอมใน Sheet · เช็กโควต้าอีเมลก่อนส่ง
 *               · กันคำขอซ้ำ/ถี่ผิดปกติ · LINE token เก็บใน Script Properties
 */

// ===== ตั้งค่า =====
const SHEET_NAME = 'คำขอลูกค้า';

// อีเมลรับแจ้งเตือนของแต่ละสาขา (เว้นว่าง = ไม่ส่งอีเมล)
const BRANCH_EMAIL = {
  faorai:      'startechfaorai@gmail.com',             // สาขาเฝ้าไร่
  chuenchom:   'startechchuenchom@gmail.com',          // สาขาชื่นชม
  kalasin:     'startechkalasin@gmail.com',            // สาขากาฬสินธุ์
  surin:       'Sales@startechsteelgroup.com',         // สำนักงานใหญ่ สุรินทร์
  khukhan:     'wiwat.k@startechsteelgroup.com',       // สาขาขุขันธ์
  prathai:     'prathai@startechsteelgroup.com',       // สาขาประทาย
  rayong:      'sikan.w@startechsteelgroup.com',       // สาขาระยอง
  prachinburi: 'witaya.m@startechsteelgroup.com',      // สาขาปราจีนบุรี
  wangnamyen:  'wanchalerm.k@startechsteelgroup.com',  // สาขาวังน้ำเย็น
  saraburi:    'saraburi@startechsteelgroup.com',      // สาขาสระบุรี
  central:     'sttm.energy@gmail.com',                // ส่วนกลาง
};
const CC_CENTRAL = true; // ส่งสำเนาทุกรายการให้ส่วนกลางด้วย
// ผู้รับสำเนาทุกรายการเพิ่มเติม
const CC_ALWAYS = [
  'kittimatsrisamer@gmail.com', // คุณหมิว
  'patty_treesak@hotmail.com',  // คุณแพท
  'o_siripong@hotmail.com',     // คุณโอ
];

// ส่งต่อเข้า startech-lead-worker → Airtable (ตาราง Leads) + LINE Admin เหมือนเครื่องคำนวณหลังคา
const FORWARD_TO_WORKER = true;
const WORKER_URL = 'https://startech-lead-worker.lively-leaf-8403.workers.dev';

// กันสแปม: เบอร์เดียวกันส่งได้ไม่เกินกี่ครั้งต่อชั่วโมง / ทั้งระบบไม่เกินกี่ครั้งต่อชั่วโมง
const MAX_PER_PHONE_PER_HOUR = 3;
const MAX_TOTAL_PER_HOUR = 60;

// (ไม่บังคับ) แจ้ง LINE ตรงจาก Apps Script — ปกติไม่ต้องใช้ เพราะ Worker แจ้ง LINE ให้แล้ว
// ถ้าจะใช้: Project Settings > Script properties > เพิ่ม LINE_TOKEN (อย่าวาง token ในโค้ด)
const LINE_TO = {}; // เช่น { faorai: 'Cxxxx', central: 'Cyyyy' }
// ===================

function doPost(e) {
  try {
    const d = JSON.parse(e.postData.contents);
    const C = d.customer || {};
    const phone = String(C.phone || '');
    if (!C.name || !/^0\d{8,9}$/.test(phone) || !d.routeTo) {
      return json_({ ok: false, error: 'invalid' });
    }
    if (!allowRequest_(phone, d.id)) return json_({ ok: false, error: 'rate_limited' });

    const rid = d.routeTo.id;
    const branchId = (rid && rid !== 'central' && BRANCH_EMAIL.hasOwnProperty(rid)) ? rid : 'central';
    const L = d.location || {}, J = d.job || {};

    // 1) บันทึกลง Google Sheet (บันทึกก่อนเสมอ ข้อมูลไม่หายแม้ขั้นต่อไปพลาด)
    const ss = SpreadsheetApp.getActiveSpreadsheet();
    const sh = ss.getSheetByName(SHEET_NAME) || ss.insertSheet(SHEET_NAME);
    if (sh.getLastRow() === 0) {
      sh.appendRow(['เวลา', 'เลขอ้างอิง', 'ประเภท', 'ส่งถึง', 'ระยะ (กม.)', 'ชื่อ', 'โทร', 'LINE',
        'จังหวัด', 'อำเภอ', 'ตำบล', 'ที่อยู่', 'แผนที่', 'หมายเหตุ', 'ทรงหลังคา', 'ขนาด (ก×ย×ส)',
        'ราคาขายวัสดุโครง', 'ข้อความเต็ม', 'สถานะ', 'ผลการส่ง']);
      sh.setFrozenRows(1);
    }
    sh.appendRow([
      new Date(), safe_(d.id), safe_(d.wantLabel), safe_(d.routeTo.name), d.routeTo.distanceKm,
      safe_(C.name), "'" + phone, safe_(C.line),
      safe_(L.province), safe_(L.district), safe_(L.tambon), safe_(L.address),
      L.lat ? 'https://maps.google.com/?q=' + Number(L.lat) + ',' + Number(L.lon) : '',
      safe_(C.note), safe_(J.roof), J.width ? J.width + '×' + J.length + '×' + J.height : '',
      J.sellTotal || '', safe_(d.message), 'รอติดต่อ', 'กำลังส่ง…'
    ]);
    const row = sh.getLastRow();
    const results = [];

    // 2) อีเมลแจ้งสาขา
    try {
      const to = BRANCH_EMAIL[branchId];
      let ccList = (CC_CENTRAL && branchId !== 'central' ? [BRANCH_EMAIL.central] : [])
        .concat(CC_ALWAYS).filter(x => x && x !== to);
      const needed = (to ? 1 : 0) + ccList.length;
      const quota = MailApp.getRemainingDailyQuota();
      if (quota < needed) ccList = quota > 1 ? ccList.slice(0, quota - 1) : []; // โควต้าใกล้หมด → ส่งสาขาก่อน
      const subject = '[' + d.wantLabel + '] ' + C.name + ' ' + phone + ' → ' + d.routeTo.name + ' (' + d.id + ')';
      if (quota < 1) {
        results.push('อีเมล: โควต้าวันนี้หมด');
      } else if (to || ccList.length) {
        MailApp.sendEmail({ to: to || ccList.join(','), cc: to ? ccList.join(',') : '', subject: subject, body: d.message || subject });
        results.push('อีเมล: ส่งแล้ว' + (ccList.length < needed - (to ? 1 : 0) ? ' (ตัดสำเนาบางส่วน โควต้าใกล้หมด)' : ''));
      }
    } catch (err) {
      results.push('อีเมล: ผิดพลาด ' + String(err).slice(0, 120));
    }

    // 3) ส่งต่อเข้า Worker → Airtable + LINE
    if (FORWARD_TO_WORKER) {
      try {
        results.push('Airtable/LINE: ' + (forwardToWorker_(d) ? 'ส่งแล้ว' : 'ไม่สำเร็จ'));
      } catch (err) {
        results.push('Airtable/LINE: ผิดพลาด ' + String(err).slice(0, 120));
      }
    }

    // 4) แจ้ง LINE ตรง (ถ้าตั้งค่าไว้)
    const lineToken = PropertiesService.getScriptProperties().getProperty('LINE_TOKEN');
    const lineTo = LINE_TO[branchId];
    if (lineToken && lineTo) {
      try {
        UrlFetchApp.fetch('https://api.line.me/v2/bot/message/push', {
          method: 'post', contentType: 'application/json',
          headers: { Authorization: 'Bearer ' + lineToken },
          payload: JSON.stringify({ to: lineTo, messages: [{ type: 'text', text: String(d.message || d.id).slice(0, 4900) }] }),
          muteHttpExceptions: true,
        });
        results.push('LINE ตรง: ส่งแล้ว');
      } catch (err) {
        results.push('LINE ตรง: ผิดพลาด');
      }
    }

    sh.getRange(row, 20).setValue(results.join(' · '));
    return json_({ ok: true, id: d.id });
  } catch (err) {
    return json_({ ok: false, error: String(err) });
  }
}

// แปลงข้อมูลแอปเป็นรูปแบบ source:"calculator" ที่ Worker รองรับอยู่แล้ว (ไม่ต้องแก้ Worker)
function forwardToWorker_(pl) {
  const j = pl.job || {}, sh = j.roofSheet || null, c = pl.customer || {}, l = pl.location || {};
  const total = j.allTotal != null ? j.allTotal : j.sellTotal;
  const money = n => Math.round(Number(n || 0)).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
  // บรรทัดแรกมีคำว่า "ความหนา" → Worker ดึงไปแสดงในข้อความ LINE
  const head = '[' + pl.wantLabel + '] โครงหลังคา (ช่าง) · ' +
    (sh && sh.thicknessMm ? 'ความหนาแผ่น ' + sh.thicknessMm + ' มม.' : 'ความหนาแผ่น: ไม่ได้เลือกแผ่นหลังคา') +
    (total != null ? ' · ยอดประมาณการ ' + money(total) + ' บาท' : '');
  const bom = [head, 'เลขอ้างอิง: ' + pl.id + ' · แอปแนะนำ: ' + ((pl.routeTo && pl.routeTo.name) || '-'), '', pl.message || ''].join('\n');
  const base = {
    source: 'calculator', name: c.name, phone: c.phone, province: l.province,
    dims: (j.width && j.length) ? j.width + ' x ' + j.length : '', area: j.roofArea || '', sheets: (sh && sh.sheets) || '',
  };
  const roofType = 'โครงหลังคา: ' + (j.roof || '-');
  const product = sh ? ((sh.type || '') + ' ' + (sh.grade || '')).trim() : 'โครงเหล็ก';
  const post = body => {
    const r = UrlFetchApp.fetch(WORKER_URL, { method: 'post', contentType: 'application/json', payload: JSON.stringify(body), muteHttpExceptions: true });
    const code = r.getResponseCode();
    return code >= 200 && code < 300;
  };
  if (post(Object.assign({}, base, { roofType: roofType, product: product, bom: bom }))) return true;
  // Airtable อาจไม่รับค่าในช่องทรง/รุ่น (single select) → ส่งซ้ำโดยย้ายไปไว้ใน BOM
  return post(Object.assign({}, base, { bom: 'ทรงหลังคา: ' + roofType + '\nรุ่นสินค้า: ' + product + '\n' + bom }));
}

// กันคำขอซ้ำ (กดส่งซ้ำ) และสแปม
function allowRequest_(phone, id) {
  const cache = CacheService.getScriptCache();
  if (id && cache.get('id:' + id)) return false;
  const pk = 'ph:' + phone, tk = 'total';
  const p = Number(cache.get(pk) || 0), t = Number(cache.get(tk) || 0);
  if (p >= MAX_PER_PHONE_PER_HOUR || t >= MAX_TOTAL_PER_HOUR) return false;
  cache.put(pk, String(p + 1), 3600);
  cache.put(tk, String(t + 1), 3600);
  if (id) cache.put('id:' + id, '1', 21600);
  return true;
}

// กันข้อความที่ขึ้นต้นด้วย = + - @ ไม่ให้ Sheet ตีความเป็นสูตร
function safe_(v) {
  const s = v == null ? '' : String(v);
  return /^[=+\-@]/.test(s) ? "'" + s : s;
}

function json_(o) {
  return ContentService.createTextOutput(JSON.stringify(o)).setMimeType(ContentService.MimeType.JSON);
}
